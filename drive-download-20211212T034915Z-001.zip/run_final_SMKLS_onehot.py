import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import mean_absolute_error, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression, Lasso
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import GridSearchCV
from sklearn.neural_network import MLPClassifier


def support_vector(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('SUPPORT VECTOR MACHINE: ')
    clf = GridSearchCV(SVC(), param_grid={'C':[0.1,1,5], 'gamma':[0.01,0.1,1]})
    # clf = SVC(C=2, kernel='rbf', gamma=0.1)
    clf.fit(df_X_train, df_y_train.iloc[:,0])
    print('BEST SVM FIT PARAMS: ', clf.best_params_)
    print('CURRENT GTRAD ERROR: ',mean_absolute_error(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))

    clf = GridSearchCV(SVC(), param_grid={'C':[0.1,1,5], 'gamma':[0.01,0.1,1]})
    # clf = SVC(C=1.5, kernel='rbf', gamma=0.1)
    clf.fit(df_X_train, df_y_train.iloc[:,1])
    print('BEST SVM FIT PARAMS: ', clf.best_params_)
    print('FORMER GTRAD ERROR: ',mean_absolute_error(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))

    clf = GridSearchCV(SVC(), param_grid={'C':[0.1,1,5], 'gamma':[0.01,0.1,1]})
    # clf = SVC(C=2.5, kernel='rbf', gamma=0.1)
    clf.fit(df_X_train, df_y_train.iloc[:,2])
    print('BEST SVM FIT PARAMS: ', clf.best_params_)
    print('NEVER GTRAD ERROR: ',mean_absolute_error(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    return clf

## LASSO
def lasso(df_X_train, df_y_train, df_X_test,df_y_test):
    print('')
    print('LASSO')
    clf = GridSearchCV(Lasso(max_iter=10000, selection='random'), {'alpha':(0.00001, 0.0001, 0.001,0.01,0.1)})
    clf.fit(df_X_train, df_y_train.iloc[:,0].astype('int'))
    print('Lasso Best Params: ',clf.best_params_)
    print('Lasso Error: ',mean_absolute_error(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))

    clf = GridSearchCV(Lasso(max_iter=10000, selection='random'), {'alpha':(0.00001, 0.0001, 0.001,0.01,0.1)})
    clf.fit(df_X_train, df_y_train.iloc[:,1].astype('int'))
    print('Lasso Best Params: ',clf.best_params_)
    print('Lasso Error: ',mean_absolute_error(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))

    clf = GridSearchCV(Lasso(max_iter=10000, selection='random'), {'alpha':(0.00001, 0.0001, 0.001,0.01,0.1)})
    clf.fit(df_X_train, df_y_train.iloc[:,2].astype('int'))
    print('Lasso Best Params: ',clf.best_params_)
    print('Lasso Error: ',mean_absolute_error(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    return clf


## LOGISTIC REGRESSION: 
def logistic_regression(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('LOGISTIC REGRESSION: ')
    lr = GridSearchCV(LogisticRegression(max_iter=1000), param_grid={'C':[0.1,1,5,10]})
    # lr = LogisticRegression(C=3,max_iter=1000)
    lr.fit(df_X_train, df_y_train.iloc[:,0])
    print('BEST CURRENT GTRAD PARAMS: ', lr.best_params_)
    print('CURRENT GTRAD ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,0]).astype('int'), lr.predict(df_X_test).astype('int')))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), lr.predict(df_X_test)))

    lr = GridSearchCV(LogisticRegression(max_iter=1000), param_grid={'C':[0.1,1,5,10]})
    # lr = LogisticRegression(C=0.5, max_iter=1000)
    lr.fit(df_X_train, df_y_train.iloc[:,1])
    print('BEST FORMER GTRAD PARAMS: ', lr.best_params_)
    print('FORMER GTRAD ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,1]).astype('int'), lr.predict(df_X_test).astype('int')))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), lr.predict(df_X_test)))

    lr = GridSearchCV(LogisticRegression(max_iter=1000), param_grid={'C':[0.1,1,5,10]})
    # lr = LogisticRegression(C = 2, max_iter=1000)
    lr.fit(df_X_train, df_y_train.iloc[:,2])
    print('BEST NEVER GTRAD PARAMS: ', lr.best_params_)
    print('NEVER GTRAD ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,2]).astype('int'), lr.predict(df_X_test).astype('int')))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), lr.predict(df_X_test)))
    return lr

def kernel_ridge(df_X_train, df_y_train, df_X_test, df_y_test, kernel='rbf'):
    print('')
    print('KERNEL RIDGE:')

    kr= GridSearchCV(KernelRidge(kernel=kernel), param_grid={'alpha': [0.5, 1, 2], 'gamma': [0.01, 0.1]})
    # kr = KernelRidge(kernel=kernel, alpha=0.5, gamma=0.01)
    kr.fit(df_X_train,df_y_train.iloc[:,0])
    print('BEST PARAMS: ', kr.best_params_)
    print('Ridge Regression Error:', mean_absolute_error(df_y_test.iloc[:,0], kr.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), kr.predict(df_X_test)))

    kr= GridSearchCV(KernelRidge(kernel=kernel), param_grid={'alpha': [0.5, 1, 2], 'gamma': [0.01, 0.1]})
    # kr = KernelRidge(kernel=kernel, alpha=0.5, gamma=0.01)
    kr.fit(df_X_train,df_y_train.iloc[:,1])
    print('BEST PARAMS: ', kr.best_params_)
    print('Ridge Regression Error:', mean_absolute_error(df_y_test.iloc[:,1], kr.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), kr.predict(df_X_test)))

    kr= GridSearchCV(KernelRidge(kernel=kernel), param_grid={'alpha': [0.5, 1, 2], 'gamma': [0.01, 0.1]})
    # kr = KernelRidge(kernel=kernel, alpha=2, gamma=0.1)
    kr.fit(df_X_train,df_y_train.iloc[:,2])
    print('BEST PARAMS: ', kr.best_params_)
    print('Ridge Regression Error:', mean_absolute_error(df_y_test.iloc[:,2], kr.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), kr.predict(df_X_test)))
    return kr

def mlp(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('MULTILAYER PERCEPTRON: ')
    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    layer_sizes = (100, 200, 100, 10)
    print('HIDDEN LAYER SIZES: ', layer_sizes)
    mlp = MLPClassifier(hidden_layer_sizes=layer_sizes, learning_rate_init=0.01, max_iter=2000)
    mlp.fit(df_X_train, df_y_train.iloc[:,0])
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('CURRENT GTRAD ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,0]).astype('int'), mlp.predict(df_X_test).astype('int')))

    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    mlp = MLPClassifier(hidden_layer_sizes=layer_sizes, learning_rate_init=0.01, max_iter=2000)
    mlp.fit(df_X_train, df_y_train.iloc[:,1])
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('CURRENT GTRAD ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,1]).astype('int'), mlp.predict(df_X_test).astype('int')))

    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    mlp = MLPClassifier(hidden_layer_sizes=layer_sizes, learning_rate_init=0.01, max_iter=2000)
    mlp.fit(df_X_train, df_y_train.iloc[:,2])
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('CURRENT GTRAD ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,2]).astype('int'), mlp.predict(df_X_test).astype('int')))

if __name__ == "__main__":

    df = pd.read_pickle('tobacco_data_onehot.pkl')

    #split the data with a 75%-25% training-test split
    # set the random state for reproducible results
    # 'R03_EVER_GFILTR''R03_EVER_GTRAD''R03_EVER_GTRAD'[8,7,6]
    pd.set_option('display.max_columns', None)
    # print(df.head())
    print('TRAINING SMKLS')
    onehot_current = df.columns != 'CURRENT_SMKLS'
    onehot_former = df.columns != 'FORMER_SMKLS'
    onehot_never = df.columns != 'NEVER_SMKLS'

    train_cols = np.logical_and(onehot_current, onehot_former)
    train_cols = np.logical_and(train_cols, onehot_never)

    df_X_train, df_X_test, df_y_train, df_y_test = train_test_split(
                                    df.loc[:, train_cols], df.loc[:, np.logical_not(train_cols)], test_size=0.2, random_state=671)
    #checks
    # print('CHECK SHAPES: ')
    # print(df_X_train.shape)
    # print(df_X_test.shape)
    # print(df_y_train.shape)
    # print(df_y_test.shape)

    logistic_regression(df_X_train, df_y_train, df_X_test, df_y_test)
    support_vector(df_X_train, df_y_train, df_X_test, df_y_test)
    kernel_ridge(df_X_train, df_y_train, df_X_test, df_y_test, kernel='rbf')
    mlp(df_X_train, df_y_train, df_X_test, df_y_test)
    lasso(df_X_train, df_y_train, df_X_test, df_y_test)