import pandas as pd
import csv

names3001 = ['PERSONID', 'R03R_A_P30D_CIGS',
'R03R_A_P30D_EPRODS',
'R03R_A_P30D_GTRAD',
'R03R_A_P30D_GRILLO',
'R03R_A_P30D_GFILTR',
'R03R_A_P30D_PIPE',
'R03R_A_P30D_HOOK',
'R03R_A_P30D_SNUS',
'R03R_A_P30D_SMKLS',
'R03R_A_AGECAT7',
'R03R_A_AT0047',
'R03R_A_HISP',
'R03R_A_RACECAT3']

names3503 = ['PERSONID', 'R03M_EVR_CIGS',
'R03M_EVR_EPRODS',
'R03M_EVR_GTRAD',
'R03M_EVR_GRILLO',
'R03M_EVR_GFILTR',
'R03M_EVR_PIPE',
'R03M_EVR_HOOK',
'R03M_EVR_SNUS',
'R03M_EVR_SMKLS']

df3001 = pd.read_csv('3001.tsv', sep='\t', usecols=names3001, index_col='PERSONID')

print(df3001.head())
print(df3001.shape)


df3503 = pd.read_csv('3503.tsv', sep='\t', usecols=names3503, index_col='PERSONID')
print(df3503.head())
print(df3001.shape)

df = pd.concat([df3001, df3503], axis=1, join='inner')
print(df.head())
print(df.shape)
'''
with open('3001.tsv') as csvfile:
    reader = csv.reader(csvfile, delimiter='\t')
    for row in reader:
        print(row)
        break
'''
df_clean = df[df >= 0]

df_clean.to_pickle('tobacco_data_clean.pkl')