#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
df = pd.read_pickle('tobacco_data_clean.pkl')
df=df.dropna()
df


# In[2]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_CIGS"][j] == 2.0 and df["R03M_EVR_CIGS"][j] == 1.0:
        userstat.append(1) # Former user
    elif df["R03M_EVR_CIGS"][j] == 2.0:
        userstat.append(2) # Never used
    else:
        userstat.append(0) # current user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_CIGS', 'R03M_EVR_CIGS'])
df['R03_EVER_CIGS'] = np.array(outsidelist,dtype=object)


# In[3]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_EPRODS"][j] == 2.0 and df["R03M_EVR_EPRODS"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_EPRODS"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_EPRODS', 'R03M_EVR_EPRODS'])
df['R03_EVER_EPRODS'] = np.array(outsidelist,dtype=object)


# In[4]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_GTRAD"][j] == 2.0 and df["R03M_EVR_GTRAD"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_GTRAD"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_GTRAD', 'R03M_EVR_GTRAD'])
df['R03_EVER_GTRAD'] = np.array(outsidelist,dtype=object)


# In[5]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_GRILLO"][j] == 2.0 and df["R03M_EVR_GRILLO"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_GRILLO"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_GRILLO', 'R03M_EVR_GRILLO'])
df['R03_EVER_GRILLO'] = np.array(outsidelist,dtype=object)


# In[6]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_GFILTR"][j] == 2.0 and df["R03M_EVR_GFILTR"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_GFILTR"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_GFILTR', 'R03M_EVR_GFILTR'])
df['R03_EVER_GFILTR'] = np.array(outsidelist,dtype=object)


# In[7]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_PIPE"][j] == 2.0 and df["R03M_EVR_PIPE"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_PIPE"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_PIPE', 'R03M_EVR_PIPE'])
df['R03_EVER_PIPE'] = np.array(outsidelist,dtype=object)
df


# In[8]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_HOOK"][j] == 2.0 and df["R03M_EVR_HOOK"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_HOOK"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_HOOK', 'R03M_EVR_HOOK'])
df['R03_EVER_HOOK'] = np.array(outsidelist,dtype=object)


# In[9]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_SNUS"][j] == 2.0 and df["R03M_EVR_SNUS"][j] == 1.0:
        userstat.append(1)
    elif df["R03M_EVR_SNUS"][j] == 2.0:
        userstat.append(2)
    else:
        userstat.append(0)
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_SNUS', 'R03M_EVR_SNUS'])
df['R03_EVER_SNUS'] = np.array(outsidelist,dtype=object)


# In[10]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_SMKLS"][j] == 2.0 and df["R03M_EVR_SMKLS"][j] == 1.0:
        userstat.append(1) # former
    elif df["R03M_EVR_SMKLS"][j] == 2.0:
        userstat.append(2) # never
    else:
        userstat.append(0) # current
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_SMKLS', 'R03M_EVR_SMKLS'])
df['R03_EVER_SMKLS'] = np.array(outsidelist,dtype=object)

col=[]
for c in df.head():
    col.append(c)

df['MARRIED'] = df['R03R_A_AT0047'] == 1.0
df['SEPARATED'] = df['R03R_A_AT0047'] == 2.0
df['NEVERMARRIED'] = df['R03R_A_AT0047'] == 3.0

df['AGECAT'] = df['R03R_A_AGECAT7']

df['HISP'] = df['R03R_A_HISP'] == 1.0

df['WHITE'] = df['R03R_A_RACECAT3'] == 1.0
df['BLACK'] = df['R03R_A_RACECAT3'] == 2.0
df['OTHER'] = df['R03R_A_RACECAT3'] == 3.0

df['CURRENT_CIGS'] = df['R03_EVER_CIGS'] == 0
df['FORMER_CIGS'] = df['R03_EVER_CIGS'] == 1
df['NEVER_CIGS'] = df['R03_EVER_CIGS'] == 2

df['CURRENT_EPRODS'] = df['R03_EVER_EPRODS'] == 0
df['FORMER_EPRODS'] = df['R03_EVER_EPRODS'] == 1
df['NEVER_EPRODS'] = df['R03_EVER_EPRODS'] == 2

df['CURRENT_GTRAD'] = df['R03_EVER_GTRAD'] == 0
df['FORMER_GTRAD'] = df['R03_EVER_GTRAD'] == 1
df['NEVER_GTRAD'] = df['R03_EVER_GTRAD'] == 2

df['CURRENT_GRILLO'] = df['R03_EVER_GRILLO'] == 0
df['FORMER_GRILLO'] = df['R03_EVER_GRILLO'] == 1
df['NEVER_GRILLO'] = df['R03_EVER_GRILLO'] == 2

df['CURRENT_GFILTR'] = df['R03_EVER_GFILTR'] == 0
df['FORMER_GFILTR'] = df['R03_EVER_GFILTR'] == 1
df['NEVER_GFILTR'] = df['R03_EVER_GFILTR'] == 2

df['CURRENT_PIPE'] = df['R03_EVER_PIPE'] == 0
df['FORMER_PIPE'] = df['R03_EVER_PIPE'] == 1
df['NEVER_PIPE'] = df['R03_EVER_PIPE'] == 2

df['CURRENT_HOOK'] = df['R03_EVER_HOOK'] == 0
df['FORMER_HOOK'] = df['R03_EVER_HOOK'] == 1
df['NEVER_HOOK'] = df['R03_EVER_HOOK'] == 2

df['CURRENT_SNUS'] = df['R03_EVER_SNUS'] == 0
df['FORMER_SNUS'] = df['R03_EVER_SNUS'] == 1
df['NEVER_SNUS'] = df['R03_EVER_SNUS'] == 2

df['CURRENT_SMKLS'] = df['R03_EVER_SMKLS'] == 0
df['FORMER_SMKLS'] = df['R03_EVER_SMKLS'] == 1
df['NEVER_SMKLS'] = df['R03_EVER_SMKLS'] == 2

print('BEFORE', df.shape)
print('DROP COLS: ',col)
df=df.drop(columns=col)
print('')
print('DROP: ', df.shape)

pd.to_pickle(df, 'tobacco_data_onehot.pkl')
