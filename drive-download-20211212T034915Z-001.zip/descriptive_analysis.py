#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import csv
import numpy as np

names3001 = ['PERSONID', 'R03R_A_P30D_CIGS',
'R03R_A_P30D_EPRODS',
'R03R_A_P30D_GTRAD',
'R03R_A_P30D_GRILLO',
'R03R_A_P30D_GFILTR',
'R03R_A_P30D_PIPE',
'R03R_A_P30D_HOOK',
'R03R_A_P30D_SNUS',
'R03R_A_P30D_SMKLS',
'R03R_A_AGECAT7',
'R03R_A_AT0047',
'R03R_A_HISP',
'R03R_A_RACECAT3']

names3503 = ['PERSONID', 'R03M_EVR_CIGS',
'R03M_EVR_EPRODS',
'R03M_EVR_GTRAD',
'R03M_EVR_GRILLO',
'R03M_EVR_GFILTR',
'R03M_EVR_PIPE',
'R03M_EVR_HOOK',
'R03M_EVR_SNUS',
'R03M_EVR_SMKLS']

df3001 = pd.read_csv('3001.tsv', sep='\t', usecols=names3001, index_col='PERSONID')

df3503 = pd.read_csv('3503.tsv', sep='\t', usecols=names3503, index_col='PERSONID')

df = pd.concat([df3001, df3503], axis=1, join='inner')

# get rid of the missing value
df_clean = df[df >= 0]

df = df_clean

outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_CIGS"][j] == 2.0 and df["R03M_EVR_CIGS"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_CIGS"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_CIGS', 'R03M_EVR_CIGS'])
df['R03_STATUS_CIGS'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_EPRODS"][j] == 2.0 and df["R03M_EVR_EPRODS"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_EPRODS"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_EPRODS', 'R03M_EVR_EPRODS'])
df['R03_STATUS_EPRODS'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_GTRAD"][j] == 2.0 and df["R03M_EVR_GTRAD"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_GTRAD"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_GTRAD', 'R03M_EVR_GTRAD'])
df['R03_STATUS_GTRAD'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_GRILLO"][j] == 2.0 and df["R03M_EVR_GRILLO"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_GRILLO"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_GRILLO', 'R03M_EVR_GRILLO'])
df['R03_STATUS_GRILLO'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_GFILTR"][j] == 2.0 and df["R03M_EVR_GFILTR"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_GFILTR"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_GFILTR', 'R03M_EVR_GFILTR'])
df['R03_STATUS_GFILTR'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_PIPE"][j] == 2.0 and df["R03M_EVR_PIPE"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_PIPE"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_PIPE', 'R03M_EVR_PIPE'])
df['R03_STATUS_PIPE'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_HOOK"][j] == 2.0 and df["R03M_EVR_HOOK"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_HOOK"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_HOOK', 'R03M_EVR_HOOK'])
df['R03_STATUS_HOOK'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_SNUS"][j] == 2.0 and df["R03M_EVR_SNUS"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_SNUS"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_SNUS', 'R03M_EVR_SNUS'])
df['R03_STATUS_SNUS'] = np.array(outsidelist,dtype=object)


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_P30D_SMKLS"][j] == 2.0 and df["R03M_EVR_SMKLS"][j] == 1.0:
        userstat.append(1)  # former user
    elif df["R03R_A_P30D_SMKLS"][j] == 1.0:
        userstat.append(2)  # current user
    else:
        userstat.append(0) # never user
    outsidelist.append(userstat)
df=df.drop(columns=['R03R_A_P30D_SMKLS', 'R03M_EVR_SMKLS'])
df['R03_STATUS_SMKLS'] = np.array(outsidelist,dtype=object)


# In[5]:


import matplotlib.pyplot as plt
import numpy as np


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_AGECAT7"][j] == 1:
        userstat.append("18-24")  
    elif df["R03R_A_AGECAT7"][j] == 2:
        userstat.append("25-34") 
    elif df["R03R_A_AGECAT7"][j] == 3:
        userstat.append("35-44") 
    elif df["R03R_A_AGECAT7"][j] == 4:
        userstat.append("45-54") 
    elif df["R03R_A_AGECAT7"][j] == 5:
        userstat.append("55-64") 
    elif df["R03R_A_AGECAT7"][j] == 6:
        userstat.append("65-74")
    else:
        userstat.append(">74")
    outsidelist.append(userstat)
df['Age'] = np.array(outsidelist,dtype=object)

labels, counts = np.unique(df['Age'],return_counts=True)

ticks = range(len(counts))
plt.bar(ticks,counts, align='center',width = 0.3)
plt.xticks(ticks, labels)
plt.ylabel('Counts',fontsize=13)
plt.xlabel('Age Group (Years old)',fontsize=13);
plt.title('Figure 1: Age Distribution',fontsize=15)


# In[6]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03R_A_RACECAT3"][j] == 1 and df["R03R_A_HISP"][j] == 2:
        userstat.append("White")  
    elif df["R03R_A_RACECAT3"][j] == 2 and df["R03R_A_HISP"][j] == 2:
        userstat.append("Black") 
    elif df["R03R_A_RACECAT3"][j] == 3 and df["R03R_A_HISP"][j] == 1:
        userstat.append("Hispanic")
    else: 
        userstat.append("Others")
    outsidelist.append(userstat)
df['Race'] = np.array(outsidelist,dtype=object)

labels, counts = np.unique(df['Race'],return_counts=True)

ticks = range(len(counts))
plt.bar(ticks,counts, align='center',width = 0.3)
plt.xticks(ticks, labels)
plt.ylabel('Counts',fontsize=13)
plt.xlabel('Race',fontsize=13);
plt.title('Figure 3: Race Distribution',fontsize=15)


# In[7]:


outsidelist=[]
for j in range(df.shape[0]):
    userstat=[]
    if df["R03_STATUS_SMKLS"][j] == 0:
        userstat.append("Never")  
    elif df["R03_STATUS_SMKLS"][j] == 1:
        userstat.append("Former") 
    else: 
        userstat.append("Current")
    outsidelist.append(userstat)
df['Cig'] = np.array(outsidelist,dtype=object)

labels, counts = np.unique(df['Cig'],return_counts=True)

ticks = range(len(counts))
plt.bar(ticks,counts, align='center',width = 0.3)
plt.xticks(ticks, labels)
plt.ylabel('Counts',fontsize=13)
plt.xlabel('Smokeless using status',fontsize=13);
plt.title('Figure 12: Smokeless using Distribution',fontsize=15)


# In[ ]:




