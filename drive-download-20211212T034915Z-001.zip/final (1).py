#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
df = pd.read_pickle('tobacco_data_onehot.pkl')
df=df.dropna()
df


# In[2]:


onehot_current = df.columns != 'CURRENT_HOOK'
onehot_former = df.columns != 'FORMER_HOOK'
onehot_never = df.columns != 'NEVER_HOOK'
from sklearn.model_selection import train_test_split
train_cols = np.logical_and(onehot_current, onehot_former)
train_cols = np.logical_and(train_cols, onehot_never)

df_X_train, df_X_test, df_y_train, df_y_test = train_test_split(
                                df.loc[:, train_cols], df.loc[:, np.logical_not(train_cols)], test_size=0.2, random_state=671)
df_X_train


# In[3]:


from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn import svm
from sklearn.svm import SVR
from sklearn.kernel_ridge import KernelRidge
from sklearn.metrics import mean_absolute_error
import warnings
from sklearn.feature_selection import SequentialFeatureSelector as sfs
from sklearn.feature_selection import SelectFromModel
from sklearn import preprocessing
import sys
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn import linear_model
from sklearn.neural_network import MLPClassifier
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import Lasso
from sklearn.metrics import precision_recall_fscore_support
from sklearn.metrics import r2_score
from sklearn.ensemble import RandomForestClassifier
def support_vector(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('SUPPORT VECTOR MACHINE: ')
    clf = SVC(C=2, kernel='rbf', gamma=0.1)
    clf.fit(df_X_train, df_y_train.iloc[:,0])
    resid0 = np.array(df_y_test.iloc[:,0]).astype(None) - clf.predict(df_X_test)
    
    AIC0= 2*29 - 2*np.log(sum(resid0**2))
    
    
    BIC0 = np.log(sum(resid0**2)/19694) + 29*np.log(19694)
    
    
    print('CURRENT HOOK ERROR: ',mean_absolute_error(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,0]).astype(None),clf.predict(df_X_test)))
    print('AIC0: ',AIC0)
    print('BIC0: ',BIC0)
    
    clf = SVC(C=1.5, kernel='rbf', gamma=0.1)
    clf.fit(df_X_train, df_y_train.iloc[:,1])
    resid1 = np.array(df_y_test.iloc[:,1]).astype(None) - clf.predict(df_X_test)
    AIC1= 2*29 - 2*np.log(sum(resid1**2))
    BIC1 = np.log(sum(resid1**2)/19694) + 29*np.log(19694)
    print('FORMER HOOK ERROR: ',mean_absolute_error(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,1]).astype(None),clf.predict(df_X_test)))
    print('AIC1: ',AIC1)
    print('BIC1: ',BIC1)

    clf = SVC(C=2.5, kernel='rbf', gamma=0.1)
    clf.fit(df_X_train, df_y_train.iloc[:,2])
    resid2 = np.array(df_y_test.iloc[:,2]).astype(None) - clf.predict(df_X_test)
    AIC2= 2*29 - 2*np.log(sum(resid2**2))
    BIC2 = np.log(sum(resid2**2)/19694) + 29*np.log(19694)
    print('NEVER HOOK ERROR: ',mean_absolute_error(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,2]).astype(None),clf.predict(df_X_test)))
    print('AIC2: ',AIC2)
    print('BIC2: ',BIC2)
    return clf


## LASSO
def lasso(df_X_train, df_y_train, df_X_test,df_y_test):
    print('')
    print('LASSO')
    clf = GridSearchCV(Lasso(max_iter=1000, selection='random'), {'alpha':(0.01, 1, 5)})
    clf.fit(df_X_train, df_y_train.iloc[:,0].astype('int'))
    resid0 = np.array(df_y_test.iloc[:,0]).astype(None) - clf.predict(df_X_test)
    
    
    AIC0= 2*29 - 2*np.log(sum(resid0**2))  
    BIC0 = np.log(sum(resid0**2)/19694) + 29*np.log(19694)
    
    print('Lasso Best Params: ',clf.best_params_)
    print('Lasso Error: ',mean_absolute_error(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,0]).astype(None),clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), clf.predict(df_X_test)))
    print('AIC0: ',AIC0)
    print('BIC0: ',BIC0)
    clf = GridSearchCV(Lasso(max_iter=1000, selection='random'), {'alpha':(0.01, 1, 5)})
    clf.fit(df_X_train, df_y_train.iloc[:,1].astype('int'))
    resid1 = np.array(df_y_test.iloc[:,1]).astype(None) - clf.predict(df_X_test)
    AIC1= 2*29 - 2*np.log(sum(resid1**2))
    BIC1 = np.log(sum(resid1**2)/19694) + 29*np.log(19694)
    print('Lasso Best Params: ',clf.best_params_)
    print('Lasso Error: ',mean_absolute_error(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,1]).astype(None),clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), clf.predict(df_X_test)))
    print('AIC1: ',AIC1)
    print('BIC1: ',BIC1)
    clf = GridSearchCV(Lasso(max_iter=1000, selection='random'), {'alpha':(0.01, 1, 5)})
    clf.fit(df_X_train, df_y_train.iloc[:,2].astype('int'))
    resid2 = np.array(df_y_test.iloc[:,2]).astype(None) - clf.predict(df_X_test)
    AIC2= 2*29 - 2*np.log(sum(resid2**2))
    BIC2 = np.log(sum(resid2**2)/19694) + 29*np.log(19694)
    print('Lasso Best Params: ',clf.best_params_)
    print('Lasso Error: ',mean_absolute_error(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,2]).astype(None),clf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), clf.predict(df_X_test)))
    print('AIC2: ',AIC2)
    print('BIC2: ',BIC2)
    return clf

## LOGISTIC REGRESSION: 
def logistic_regression(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('LOGISTIC REGRESSION: ')
    # lr = GridSearchCV(LogisticRegression(max_iter=1000), param_grid={'C':[2,2.5,3,3.5,4]})
    lr = LogisticRegression(C=3,max_iter=1000)
    lr.fit(df_X_train, df_y_train.iloc[:,0])
    resid0 = np.array(df_y_test.iloc[:,0]).astype(None) - lr.predict(df_X_test)   
    AIC0= 2*29 - 2*np.log(sum(resid0**2))
    BIC0 = np.log(sum(resid0**2)/19694) + 29*np.log(19694)
    # print('BEST CURRENT GTRAD PARAMS: ', lr.best_params_)
    print('CURRENT HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,0]).astype('int'), lr.predict(df_X_test).astype('int')))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), lr.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,0]).astype(None),lr.predict(df_X_test)))
    print('AIC0: ',AIC0)
    print('BIC0: ',BIC0)
    # lr = GridSearchCV(LogisticRegression(max_iter=1000), param_grid={'C':[0.1,0.3,0.5,0.7,0.9]})
    lr = LogisticRegression(C=0.5, max_iter=1000)
    lr.fit(df_X_train, df_y_train.iloc[:,1])
    resid1 = np.array(df_y_test.iloc[:,1]).astype(None) - lr.predict(df_X_test)
    AIC1= 2*29 - 2*np.log(sum(resid1**2))
    BIC1 = np.log(sum(resid1**2)/19694) + 29*np.log(19694)
    # print('BEST FORMER GTRAD PARAMS: ', lr.best_params_)
    print('FORMER HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,1]).astype('int'), lr.predict(df_X_test).astype('int')))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), lr.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,1]).astype(None),lr.predict(df_X_test)))
    print('AIC1: ',AIC1)
    print('BIC1: ',BIC1)
    # lr = GridSearchCV(LogisticRegression(max_iter=1000), param_grid={'C':[1.5,2,2.5]})
    lr = LogisticRegression(C = 2, max_iter=1000)
    lr.fit(df_X_train, df_y_train.iloc[:,2])
    resid2 = np.array(df_y_test.iloc[:,2]).astype(None) - lr.predict(df_X_test)
    AIC2= 2*29 - 2*np.log(sum(resid2**2))
    BIC2 = np.log(sum(resid2**2)/19694) + 29*np.log(19694)
    # print('BEST NEVER GTRAD PARAMS: ', lr.best_params_)
    print('NEVER HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,2]).astype('int'), lr.predict(df_X_test).astype('int')))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), lr.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,2]).astype(None),lr.predict(df_X_test)))
    print('AIC2: ',AIC2)
    print('BIC2: ',BIC2)
    return lr

def kernel_ridge(df_X_train, df_y_train, df_X_test, df_y_test, kernel='rbf'):
    print('')
    print('KERNEL RIDGE:')

    # kr= GridSearchCV(KernelRidge(kernel=kernel), param_grid={'alpha': [0.5, 1, 2], 'gamma': [0.01, 0.1]})
    kr = KernelRidge(kernel=kernel, alpha=0.5, gamma=0.01)
    kr.fit(df_X_train,df_y_train.iloc[:,0])
    resid0 = np.array(df_y_test.iloc[:,0]).astype(None) - kr.predict(df_X_test)
    AIC0= 2*29 - 2*np.log(sum(resid0**2))
    BIC0 = np.log(sum(resid0**2)/19694) + 29*np.log(19694)
    # print('BEST PARAMS: ', kr.best_params_)
    print('Ridge Regression Error:', mean_absolute_error(df_y_test.iloc[:,0], kr.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), kr.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,0]).astype(None),kr.predict(df_X_test)))
    print('AIC0: ',AIC0)
    print('BIC0: ',BIC0)
    # kr= GridSearchCV(KernelRidge(kernel=kernel), param_grid={'alpha': [0.5, 1, 2], 'gamma': [0.01, 0.1]})
    kr = KernelRidge(kernel=kernel, alpha=0.5, gamma=0.01)
    kr.fit(df_X_train,df_y_train.iloc[:,1])
    resid1 = np.array(df_y_test.iloc[:,1]).astype(None) - kr.predict(df_X_test)
    AIC1= 2*29 - 2*np.log(sum(resid1**2))
    BIC1 = np.log(sum(resid1**2)/19694) + 29*np.log(19694)
    # print('BEST PARAMS: ', kr.best_params_)
    print('Ridge Regression Error:', mean_absolute_error(df_y_test.iloc[:,1], kr.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), kr.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,1]).astype(None),kr.predict(df_X_test)))
    print('AIC1: ',AIC1)
    print('BIC1: ',BIC1)
    # kr= GridSearchCV(KernelRidge(kernel=kernel), param_grid={'alpha': [0.5, 1, 2], 'gamma': [0.01, 0.1]})
    kr = KernelRidge(kernel=kernel, alpha=2, gamma=0.1)
    kr.fit(df_X_train,df_y_train.iloc[:,2])
    resid2 = np.array(df_y_test.iloc[:,2]).astype(None) - kr.predict(df_X_test)
    AIC2= 2*29 - 2*np.log(sum(resid2**2))
    BIC2 = np.log(sum(resid2**2)/19694) + 29*np.log(19694)
    # print('BEST PARAMS: ', kr.best_params_)
    print('Ridge Regression Error:', mean_absolute_error(df_y_test.iloc[:,2], kr.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), kr.predict(df_X_test)))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,2]).astype(None),kr.predict(df_X_test)))
    print('AIC2: ',AIC2)
    print('BIC2: ',BIC2)
    return kr

def mlp(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('MULTILAYER PERCEPTRON: ')
    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    layer_sizes = (100, 200, 100, 10)
    print('HIDDEN LAYER SIZES: ', layer_sizes)
    mlp = MLPClassifier(hidden_layer_sizes=layer_sizes, learning_rate_init=0.01, max_iter=2000)
    mlp.fit(df_X_train, df_y_train.iloc[:,0])
    resid0 = np.array(df_y_test.iloc[:,0]).astype(None) - mlp.predict(df_X_test)
    AIC0= 2*29 - 2*np.log(sum(resid0**2))
    BIC0 = np.log(sum(resid0**2)/19694) + 29*np.log(19694)
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('CURRENT HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,0]).astype('int'), mlp.predict(df_X_test).astype('int')))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,0]).astype(None),mlp.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), mlp.predict(df_X_test)))
    print('AIC0: ',AIC0)
    print('BIC0: ',BIC0)

    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    mlp = MLPClassifier(hidden_layer_sizes=layer_sizes, learning_rate_init=0.01, max_iter=2000)
    mlp.fit(df_X_train, df_y_train.iloc[:,1])
    resid1 = np.array(df_y_test.iloc[:,1]).astype(None) - mlp.predict(df_X_test)
    AIC1= 2*29 - 2*np.log(sum(resid1**2))
    BIC1 = np.log(sum(resid1**2)/19694) + 29*np.log(19694)
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('CURRENT HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,1]).astype('int'), mlp.predict(df_X_test).astype('int')))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,1]).astype(None),mlp.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), mlp.predict(df_X_test)))
    print('AIC1: ',AIC1)
    print('BIC1: ',BIC1)

    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    mlp = MLPClassifier(hidden_layer_sizes=layer_sizes, learning_rate_init=0.01, max_iter=2000)
    mlp.fit(df_X_train, df_y_train.iloc[:,2])
    resid2 = np.array(df_y_test.iloc[:,2]).astype(None) - mlp.predict(df_X_test)
    AIC2= 2*29 - 2*np.log(sum(resid2**2))
    BIC2 = np.log(sum(resid2**2)/19694) + 29*np.log(19694)
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('CURRENT HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,2]).astype('int'), mlp.predict(df_X_test).astype('int')))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,2]).astype(None),mlp.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), mlp.predict(df_X_test)))
    print('AIC2: ',AIC2)
    print('BIC2: ',BIC2)

def rf(df_X_train, df_y_train, df_X_test, df_y_test):
    print('')
    print('RANDOM FOREST: ')
    # mlp = GridSearchCV(MLPClassifier(), {'hidden_layer_sizes': [(5,), (10,), (20,), (50,)], 'alpha': [0.00001, 0.0001, 0.001, 0.01]})
    #layer_sizes = (100, 200, 100, 10)
    #print('HIDDEN LAYER SIZES: ', layer_sizes)
    rf = RandomForestClassifier(n_estimators=100,max_depth=10,random_state=2)
    rf.fit(df_X_train, df_y_train.iloc[:,0].astype('int').values.ravel())
    resid0 = np.array(df_y_test.iloc[:,0]).astype(None) - rf.predict(df_X_test)
    AIC0= 2*29 - 2*np.log(sum(resid0**2))
    BIC0 = np.log(sum(resid0**2)/19694) + 29*np.log(19694)
    #print(rf.best_params_)
    print('RF HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,0]).astype('int'), rf.predict(df_X_test).astype('int')))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,0]).astype(None),rf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,0].astype('int'), rf.predict(df_X_test)))
    print('AIC0: ',AIC0)
    print('BIC0: ',BIC0)

    rf.fit(df_X_train, df_y_train.iloc[:,1])
    resid1 = np.array(df_y_test.iloc[:,1]).astype(None) - rf.predict(df_X_test)
    AIC1= 2*29 - 2*np.log(sum(resid1**2))
    BIC1 = np.log(sum(resid1**2)/19694) + 29*np.log(19694)
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('RF HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,1]).astype('int'), rf.predict(df_X_test).astype('int')))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,1]).astype(None),rf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,1].astype('int'), rf.predict(df_X_test)))
    print('AIC1: ',AIC1)
    print('BIC1: ',BIC1)

    rf.fit(df_X_train, df_y_train.iloc[:,2])
    resid2 = np.array(df_y_test.iloc[:,2]).astype(None) - rf.predict(df_X_test)
    AIC2= 2*29 - 2*np.log(sum(resid2**2))
    BIC2 = np.log(sum(resid2**2)/19694) + 29*np.log(19694)
    # print('BEST CURRENT GTRAD PARAMS: ', mlp.best_params_)
    print('RF HOOK ERROR: ',mean_absolute_error(np.array(df_y_test.iloc[:,2]).astype('int'), rf.predict(df_X_test).astype('int')))
    print(metrics.r2_score(np.array(df_y_test.iloc[:,2]).astype(None),rf.predict(df_X_test)))
    print(' >> AUC = ', roc_auc_score(df_y_test.iloc[:,2].astype('int'), rf.predict(df_X_test)))
    print('AIC2: ',AIC2)
    print('BIC2: ',BIC2)


# In[ ]:


logistic_regression(df_X_train, df_y_train, df_X_test, df_y_test)
support_vector(df_X_train, df_y_train, df_X_test, df_y_test)
kernel_ridge(df_X_train, df_y_train, df_X_test, df_y_test, kernel='rbf')
mlp(df_X_train, df_y_train, df_X_test, df_y_test)
lasso(df_X_train, df_y_train, df_X_test, df_y_test)
rf(df_X_train, df_y_train, df_X_test, df_y_test)


# In[ ]:





# In[ ]:





# In[ ]:




